<?php

const DB_HOST = 'localhost';
const DB_DATABASE = 'wd18341';
const DB_USERNAME = 'root';
const DB_PASSWORD = '';