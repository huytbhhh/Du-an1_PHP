# Hướng dẫn cài đặt trên Laragon

1. Truy cập cập thư mục root của Laragon
2. Clone code: ```git clone https://github.com/tongvanduc/fpoly-base-mvc.git [ten_du_an]```
3. Mở terminal của Laragon và chạy:
    3.1. Di chuyển vào trong dự án: ```cd ten_du_an```
    3.2. Chạy lệnh: ```composer update```
    3.3. Chạy lệnh xóa git của Thầy: ```rm -rf .git```
4. Cấu hình kết nối MySQL: ```Di chuyển vào file global.php điển thông tin tương ứng```
5. Stop -> Start Laragon
6. Truy cập domain tương ứng với dự án.